def normalize_symbol(symbol: str) -> str:
    return symbol.split(".")[0]